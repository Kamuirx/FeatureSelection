# Measures based on the chi squared test. Individual Measures

cramer <- function(data, class, features) {
	measures <- NULL

	# Get values of the features and the class
	features <- unlist(features) 
	feature.data <- data[, features, drop=FALSE] 
	classes <- c(data[[class]]) 
	
	# For each individual feature...
	for (i in feature.data) {
	 # Count the number of times that each class is repeated for an feature value
	  joint <- table(classes, i) 
	  
	  # Count the number of times the class 'j' appears
	  row.sums <- rowSums(joint) 
	  
	  # Count the number of times the value 'i' appears in the feature
	  feature.count <- colSums(joint)
	 
	  # Calculate frequency of each class
	  num.elements <- length(i)
	  class.prob <- as.matrix(row.sums) / num.elements
	  
	  # Transpose matrix with t() function, and calculate matrix multiplication
	  expected <- t(as.matrix(feature.count) %*% t(as.matrix(class.prob)))
	  # (observed - expected)² / expected
	  chi.squared <- sum(((joint - expected) ^ 2) / expected)

	  # Calculate Cramer V measure: sqrt( (X²/n) / (min(k-1, r-1))
    if (length(row.sums) < 2 || length(feature.count) < 2 || chi.squared == 0) {
      result <- 0
    } else {
      k <- ncol(joint)
      r <- nrow(joint)
      cramer <- sqrt( (chi.squared / num.elements) / min(k-1, r-1))
      result <- cramer
    } 	 
	  # Store a value for each feature
    measures[[length(measures) + 1]] <- result 
	}
  return(measures)
}

chiSquared <- function(data, class, features) {
  measures <- NULL
  
  # Get values of the features and the class
  features <- unlist(features) 
  feature.data <- data[, features, drop=FALSE] 
  classes <- c(data[[class]]) 

  # For each individual feature...
  for (i in feature.data) {
    # Count the number of times that each class is repeated for an feature value
    joint <- table(classes, i) 
    
    # Count the number of times the class 'j' appears
    row.sums <- rowSums(joint) 
    
    # Count the number of times the value 'i' appears in the feature
    feature.count <- colSums(joint) 
    
    # Calculate frequency of each class
    num.elements <- length(i)
    class.prob <- as.matrix(row.sums) / num.elements
    
    # Transpose matrix with t() function, and calculate matrix multiplication
    expected <- t(as.matrix(feature.count) %*% t(as.matrix(class.prob)))
    chi.squared <- sum(((joint - expected) ^ 2) / expected)
    
    # Store a value for each feature
    measures[[length(measures) + 1]] <- chi.squared 
  }
  return(measures)
}