# Only for regression problems, when the class is continous
determinationCoefficient <- function(data, class, features) {
  # Create the formula formed with the features and the class
  formula <- as.formula(paste(class, "~", paste(features, collapse="+"))) 
  
  # Fit the linear model
  model <- lm(data = data, formula) 
  
  # Take the measure
  value <- summary(model)$r.squared 
  
  return(value)
}
suppressWarnings(warning("In summary.lm(model) : essentially perfect fit: summary may be unreliable"))
