giniIndex <- function(data, class, features) {
  # Get values of the features
  features <- unlist(features) 
  feature.data <- data[, features, drop=FALSE]

  # We will store the values of each feature in a hash table
  hash.vector <- as.factor(apply(feature.data, 1, digest)) 

  # Calculate Gini of each value of the feature
  gini <- function(vector) {
    gini.result <- 0
    for (i in vector)
      gini.result <- gini.result + (i / sum(vector)) ^ 2
    
    return(gini.result)
  }
  
  # Store the gini index of each feature value
  result <- aggregate(data[[class]], list(hash=hash.vector), function(classes) {
    return(gini(as.vector(table(classes)))) 
  }) 
  
  # Store the number of times each feature value appears
  ni <- aggregate(data[[class]], list(hash = hash.vector), function(classes) {
    return (sum(table(classes)))  
  })
  div <- (ni[[dim(ni)[2]]] / dim(feature.data)[1])
 
  # Final gini index of the feature
  final.gini <- (sum(div * result[[dim(result)[2]]]))
  
  return(final.gini)
}