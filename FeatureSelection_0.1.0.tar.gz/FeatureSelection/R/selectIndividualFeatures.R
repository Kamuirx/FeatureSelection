# Cutting criteria

selectKBest <- function(data, class, featureSetEval, k) {
  # Take only the features of the data set
  column.names <- names(data) 
  class.position <- which(column.names == class) 
  features <- data[-class.position] 

  # Check if the k value is valid
  if (k <= 0) {
    stop("k should be > 0")
  } else if (k == 'all') {
    return (features)
  } else if (k > nrow(features)) {
    k <- ncol(features)
  }
  values <- NULL
  names <- NULL

  # Evaluate each feature separately
  for (i in colnames(features)) {
    names[[length(names) + 1]] <- i
    value <- featureSetEval(data, class, i)
    values[[length(values) + 1]] <- value
  }

  # Sort the features in descending order
  feats <- data.frame(values)
  rownames(feats) <- names
  sorted.features <- rownames(feats)[order(-feats$values)] 
  
  # Select features according to the k highest scores
  return(sorted.features[1:k])
}

selectPercentile <- function(data, class, featureSetEval, percentile) {
  # Take only the features of the data set
  column.names <- names(data) 
  class.position <- which(column.names == class) 
  features <- data[-class.position] 

  values <- NULL
  names <- NULL
  
  # Evaluate each feature separately
  for (i in colnames(features)) {
    names[[length(names) + 1]] <- i
    value <- featureSetEval(data, class, i)
    values[[length(values) + 1]] <- value
  }
  feats <- data.frame(values)
  rownames(feats) <- names
  
  # Check if the percentile value is valid
  if (percentile < 0 || percentile > 100) {
    stop ("Percentile should be >=0 and <= 100")
  }
  else {
    percentile <- percentile / 100
    sorted.features <- rownames(feats)[order(-feats$values)] 
    max.features <- (length(sorted.features) * percentile)

    # Select features according to a percentile of the highest scores.
    return (sorted.features[1:round(max.features)])
  }
}

# Features with a value lower than the threshold, will be removed
selectThreshold <- function(data, class, featureSetEval, threshold) {
  # Take only the features of the data set
  column.names <- names(data) 
  class.position <- which(column.names == class)
  features <- data[-class.position] 
  
  values <- NULL
  names <- NULL
  
  # Evaluate each feature separately
  for (i in colnames(features)) {
    names[[length(names) + 1]] <- i
    value <- featureSetEval(data, class, i)
    values[[length(values) + 1]] <- value
  }
  feats <- data.frame(values)
  rownames(feats) <- names
  over.threshold <- NULL
  
  # Select the features that exceed the threshold
  for (i in feats$values) {
    if (i > threshold) {
      row <- (rownames(feats)[feats$value == i])
      over.threshold <- c(over.threshold, row)
    }
  }
  return (unique(over.threshold))
}

# Evaluation over a threshold given as a fraction of the range of evaluation
selectThresholdRange <- function(data, class, featureSetEval, p.threshold) {
  # Take only the features of the data set
  column.names <- names(data) 
  class.position <- which(column.names == class) 
  features <- data[-class.position] 

  values <- NULL
  names <- NULL
  
  # Evaluate each feature separately
  for (i in colnames(features)) {
    names[[length(names) + 1]] <- i
    value <- featureSetEval(data, class, i)
    values[[length(values) + 1]] <- value
  }
  feats <- data.frame(values)
  rownames(feats) <- names

  # Take the max and min value to evaluate the threshold
  max <- max(feats)
  min <- min(feats)
  threshold <- ((max - min) * p.threshold) + min

  over.threshold <- NULL

  # Select the features that exceed the threshold
  for (i in feats$values) {
    if (i > threshold) {
      row <- (rownames(feats)[feats$values == i])
      over.threshold <- c(over.threshold, row)
    }
  }
  return (unique(over.threshold))
}

selectDifference <- function(data, class, featureSetEval, d.threshold) {
  # Take only the features of the data set
  column.names <- names(data) 
  class.position <- which(column.names == class) 
  features <- data[-class.position] 
  
  values <- NULL
  names <- NULL
  
  # Evaluate each feature separately
  for (i in colnames(features)) {
    names[[length(names) + 1]] <- i
    value <- featureSetEval(data, class, i)
    values[[length(values) + 1]] <- value
  }
  feats <- data.frame(values)
  rownames(feats) <- names
  
  # Sort the features in descending order
  sorted.features <- rownames(feats)[order(-feats$values)] 
  sorted.values <- feats$values[order(-feats$values)]
  sorted.frame <- data.frame(row.names=sorted.features, values = sorted.values)
  difference <- 0
  num.features <- nrow(sorted.frame)
  under.threshold <- NULL
  
  # Always select the first feature
  row <- (rownames(sorted.frame)[1])
  under.threshold <- c(under.threshold, row)
  
  # Select the features whose difference does not exceed the threshold
  for (i in 1:num.features) {
    if (i == num.features)
      break
    else {
      # Calculate the difference between 2 features
      first <- sorted.frame$values[i]
      second <- sorted.frame$values[i+1]
      difference <- first - second

      # Select features that meet the criteria
      if (difference < d.threshold) {
        row <- (rownames(sorted.frame)[sorted.frame$values==sorted.frame[i+1,]])
        under.threshold <- c(under.threshold, row) 
      } else { 
        break
      }
    }
  }
  return (unique(under.threshold))
}

selectSlope <- function(data, class, featureSetEval, s.threshold) {
  column.names <- names(data) 
  class.position <- which(column.names == class) 
  features <- data[-class.position] 
  n <- ncol(features)

  # Calculate the slope
  s.threshold <- s.threshold / n

  # Select features until the slope to the next feature is over a threshold
  selectDifference(data, class, featureSetEval, s.threshold)
}