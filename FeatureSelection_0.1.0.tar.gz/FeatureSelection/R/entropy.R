# Measures based on information theory

entropy <- function(x) {
  # Calculate the frequency of each value of the feature
  freqs <- table(x) / length(x) 
  freqs <- as.vector(freqs)   
  
  # Calculate the entropy
  result <- - sum (freqs * log2(freqs))   
  
  return(result) 
}

entropyJ <- function(x) {
  # Calculate the frequency of each value of the feature in the selected class
  freqs <- x / sum(x) 
  freqs <- as.vector(freqs)    
  logs <- freqs * log2(freqs)
  logs <- replace(logs, is.na(logs), 0)
  
  # Calculate the joint entropy
  summatory <- - sum(logs)
  
  return(summatory)
}

mutualInformation <- function(data, class, features) {
  # Get values of the features
  features <- unlist(features) 
  feature.data <- data[, features, drop=FALSE] 
  
  # Calculate entropy of the class
  classes <- c(data[[class]]) # Obtenemos valores de la clase en numeros
  class.entropy <- entropy(classes)

  # To calculate the measure of only one feature...
  if (ncol(feature.data) == 1) {
    # Calculate the entropy of the feature
    features.entropies <- sapply(feature.data, entropy) 
    vector <- unlist(feature.data) 
    
    # Calculate joint entropy between the feature and the class
    joint.entropy <- entropyJ(table(vector, classes))
    
    # To calculate the measure of only 2 or more features...
  } else { 
      # Calculate joint entropy between the features
      features.entropies <- entropyJ(table(feature.data))
      tabla <- data.frame(feature.data, classes)
      
      # Calculate joint entropy between the features and the class
      joint.entropy <- entropyJ(table(tabla))
  }
  
  # Calculate the mutual information
  result <- class.entropy + unname(features.entropies) - joint.entropy
  
  return(result)
}

gainRatio <- function(data, class, features) {
  # Get values of the features
  features <- unlist(features) 
  feature.data <- data[, features, drop=FALSE] 

  # Calculate the entropy of the features
  if (ncol(feature.data) == 1) {
    features.entropies <- sapply(feature.data, entropy) 
  } else {
      features.entropies <- entropyJ(table(feature.data))
  }

  # Invoke the mutual information function
  mutual.information <- mutualInformation(data, class, features)
  
  # Calculate the Gain Ratio
  gain <- mutual.information / unname(features.entropies)
  
  if (is.nan(gain))
    gain <- 0

  return(gain)
}

symmetricalUncertain <- function(data, class, features) {
  # Get values of the features
  features <- unlist(features) 
  feature.data <- data[, features, drop=FALSE] 

  # Calculate entropy of the class
  classes <- c(data[[class]]) # Obtenemos valores de la clase en numeros
  class.entropy <- entropy(classes)

  # Calculate the entropy of the features
  if (ncol(feature.data) == 1) {
    features.entropies <- sapply(feature.data, entropy) 
  } else {
      features.entropies <- entropyJ(table(feature.data))
  }
  
  # Invoke the mutual information function
  mutual.information <- mutualInformation(data, class, features)
  
  # calculate the symmetrical uncertain
  symm.uncertain <- (2 * mutual.information) / (class.entropy + unname(features.entropies))

  return(symm.uncertain)
}