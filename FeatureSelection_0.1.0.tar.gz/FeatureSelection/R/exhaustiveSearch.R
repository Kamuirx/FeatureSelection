# Exhaustive search in breadth order
breadthFirstSearch <- function(data, class, featureSetEval) {
  # Extract and eliminate the class to have only the features in 'features'
  column.names <- names(data) 
  class.position <- which(column.names == class)
  features <- column.names[-class.position]
  
  # In best.set, we store the features that are part of the solution
  best.set <- NULL
  best.value <- NULL
  
  # Queue the root of the tree
  queue <- NULL
  queue[[length(queue)+1]] <- list(list(), as.list(features))

  # Visite each feature
  while (length(queue) > 0) {
    # Pop (introduce) an unvisited node 
    node <- queue[[1]] 
    trunk <- node[[1]] 
    branches <- node[[2]]
    queue[[1]] <- NULL
    
    # visit each branch of the current node
    for (i in seq(along=branches)) {
      set <- c(trunk, branches[[i]])
      
      # Evaluate and check if better
      value <- featureSetEval(data, class, set)

      # Store the new feature if is better
      if (is.null(best.value) || value > best.value) {
        best.value <- value
        best.set <- set
      }
      # Generate branch nodes if there are remaining features to combine
      n <- length(branches)
      if (i < n) {
        queue[[length(queue)+1]] <- list(set, branches[(i+1):n])
      }
    }
  }
  paste(best.set, sep = " ")
}