# Sequential Searchs

sfs <- function(data, class, featureSetEval) {
  # Extract and eliminate the class to have only the features 'features'
  column.names <- names(data) 
  class.position <- which(column.names == class) 
  features <- column.names[-class.position] 
  
  # In feat.sub we store the features that are part of the solution
  feat.sub <- NULL 
  value.max <- 0

  # For each feature...
  for (i in seq(along = features)) {
    # Find the best feature (only 1) to be included in this step
    best.feat <- NULL
    best.feat.value <- NULL

    # Try to include a feature in the best.feat array
    for (j in seq(along = features)) {
      feat <- features[[j]] 

      # Find the best feature to include in the result set of features
      if (! feat %in% feat.sub) {
        value <- featureSetEval(data, class, c(feat.sub, feat)) 
        
        if (is.null(best.feat.value) || value > best.feat.value) {
          best.feat.value <- value
          best.feat <- feat
        }
      }
    }

    # Always save the best evaluation
    if (length(feat.sub) > 0)
      value.max <- featureSetEval(data, class, feat.sub)

    # If including the new feature, we have a better set of features, include it
    if(best.feat.value > value.max) {
      feat.sub[[length(feat.sub) + 1]] <- best.feat 

      # Remove the included feature, to not evalute it again
      features <- features[features != best.feat]
    }
  }
  paste(feat.sub, sep = " ")
}

sffs <- function(data, class, featureSetEval) {
  # Extract and eliminate the class to have only the features in 'features'
  column.names <- names(data) 
  class.position <- which(column.names == class) 
  features <- column.names[-class.position] 
  feat.sub <- NULL 
  value.max <- 0

  # Step 1 (Inclusion): Find the best feature to be included in this step
  for (i in seq(along = features)) {
    best.feat <- NULL
    best.feat.value <- NULL

    # Try to include a feature in the best.feat array
    for (j in seq(along = features)) {
      feat <- features[[j]]

      # Find the best feature to include in the result set of features
      if (! feat %in% feat.sub) {
        value <- featureSetEval(data, class, c(feat.sub, feat)) 

        if (is.null(best.feat.value) || value > best.feat.value) {
          best.feat.value <- value
          best.feat <- feat
        }
      }
    }

    # Always save the best evaluation
    if (length(feat.sub) > 0)
      value.max <- featureSetEval(data, class, feat.sub)

    # If including the new feature, we have a better set of features, include it
    if(best.feat.value > value.max) {
      feat.sub[[length(feat.sub) + 1]] <- best.feat 
      features <- features[features != best.feat]

      # Step 2: Conditional exclusion. Now, if removing a feature, we get a 
      # better set of features. We remove it
      if(length(feat.sub) > 1) {
        crit.func.max <- featureSetEval(data, class, feat.sub) 
        continue <- TRUE
        
        # We can exclude 1 or more features in each step
        while (continue == TRUE) {
          worst.feat.value <- FALSE
          for (i in seq(along=feat.sub)) {
            feat <- feat.sub[[i]] 
            feat.prueba <- feat.sub
            feat.prueba <- feat.prueba[feat.prueba != feat]
            crit.func.eval <- featureSetEval(data, class, feat.prueba)

            # Check if removing the feature, we get a better or even evaluation
            if (crit.func.eval >= crit.func.max) {
              worst.feat <- feat
              crit.func.max <- crit.func.eval
              worst.feat.value <- TRUE
              # Do not remove the feature that was just included
              if(worst.feat == best.feat) 
                worst.feat.value <- FALSE
            }
          }
          # Remove the feature 
          if (worst.feat.value == TRUE) {
            feat.sub <- feat.sub[feat.sub != worst.feat]
            features[[length(features) + 1]] <- worst.feat
          } else {
            continue <- FALSE
          }
        }
      }
    }
  }
  paste(feat.sub, sep = " ")
}

sbs <- function(data, class, featureSetEval) {
  # Extract and eliminate the class to have only the features in 'features'
  column.names <- names(data) 
  class.position <- which(column.names == class) 
  features <- column.names[-class.position] 
  feat.sub <- as.vector(features)
  excluded.features <- NULL

  for (i in seq(length(features) - 1)) {
    best.value <- featureSetEval(data, class, feat.sub)
    best.feat <- NULL
    best.feat.value <- NULL

    # Step 1 (Exclusion): Eliminate a feature in each step, if with it, 
    # we can get a better evaluation (if not, end of the algorithm)
    for (i in seq(along = feat.sub)) {
      feat <- feat.sub[[i]]
      feat.prueba <- feat.sub
      feat.prueba <- feat.prueba[feat.prueba != feat]
      value <- featureSetEval(data, class, feat.prueba)

      # Find the feature that removing it, we can get a better evaluation
      if (is.null(best.feat.value) || best.feat.value < value) {
        best.feat.value <- value
        best.feat <- feat
      }
    }

    # If removing it we can get a better of even evaluation, we remove it
    if (is.null(best.value) || best.value <= best.feat.value) {
      best.value <- best.feat.value
      
      # Remove the selected feature
      feat.sub <- feat.sub[feat.sub != best.feat]
    }
  }
  paste(feat.sub, sep = " ")
}

sfbs <- function(data, class, featureSetEval) {
  # Extract and eliminate the class to have only the features in 'features'
  column.names <- names(data) 
  class.position <- which(column.names == class) 
  features <- column.names[-class.position] 
  feat.sub <- as.vector(features)
  excluded.features <- NULL

  for (i in seq(length(features) - 1)) {
    best.value <- featureSetEval(data, class, feat.sub)

    # Step 1 (Exclusion): Eliminate a feature in each step, if with it, 
    # we can get a better evaluation (if not, end of the algorithm)
    best.feat <- NULL
    best.feat.value <- NULL

    for (i in seq(along = feat.sub)) {
      feat <- feat.sub[[i]]
      feat.prueba <- feat.sub
      feat.prueba <- feat.prueba[feat.prueba != feat]
      value <- featureSetEval(data, class, feat.prueba)

      # Find the feature that removing it, we can get a better evaluation
      if (is.null(best.feat.value) || best.feat.value < value) {
        best.feat.value <- value
        best.feat <- feat
      }
    }
    # If removing it we can get a better of even evaluation, we remove it
    if (is.null(best.value) || best.value <= best.feat.value) {
      best.value <- best.feat.value
      
      # Remove the selected feature
      feat.sub <- feat.sub[feat.sub != best.feat]
      
      # Save the excluded feature for the future
      excluded.features[[length(excluded.features) + 1]] <- best.feat

      # Step 2: Conditional inclusion.
      crit.func.max <- featureSetEval(data, class, feat.sub) 
      continue <- TRUE

      # We can include 1 or more features in each step
      while (continue == TRUE) {
        worst.feat.value <- FALSE
        
        # See if including a feature of the removed, we can get a better set
        for (i in seq(along = excluded.features)) {
          feat <- excluded.features[[i]] 
          feat.prueba <- feat.sub
          feat.prueba[[length(feat.prueba) + 1]] <- feat
          crit.func.eval <- featureSetEval(data, class, feat.prueba)

          if (crit.func.eval > crit.func.max) {
            worst.feat <- feat
            crit.func.max <- crit.func.eval
            worst.feat.value <- TRUE
            
            # Do not include the feature that was just removed
            if(worst.feat == best.feat) 
              worst.feat.value <- FALSE
          }
        }
        # Include the feature in the result set of features
        if (worst.feat.value == TRUE) {
          feat.sub[[length(feat.sub) + 1]] <- worst.feat
          excluded.features <- excluded.features[excluded.features!=worst.feat]  
        } else {
          continue <- FALSE
        }
      }
    }
  }
  paste(feat.sub, sep = " ")
}