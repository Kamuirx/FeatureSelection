# The wapper measure will invoke a learning algorithm: lm, rpart, neuralnet 
# or knn rpart and knn for classification problems. Neuralnet and lm for 
# regression problems
wrapperParameters <- function(k.fold, type=c("lm", "rpart", "neuralnet", "knn")) 
{
  k.fold <- k.fold
  type <- type
  
  wrapper <- function(data, class, features) {
    # Check if the k.fold value is correct
    if (k.fold < 2) {
      stop ("The value of kFold must be >= 2")
    } else if (k.fold > nrow(data)) {
      k.fold <- nrow(data) 
    }
    
    # Randomly shuffle the data
    data <- data[sample(nrow(data)), ]
    
    # Create k equally size folds
    folds <- cut(seq(1, nrow(data)), breaks = k.fold, labels=FALSE)
    
    # Create the formula for the learning algorithm
    formula <- as.formula(paste(class, '~', paste(features, collapse = "+")))
    ccr <- NULL
    mse <- NULL
    
    # Perform k fold cross validation
    for (i in 1:k.fold) {
      # Segment the data by fold using the which() function 
      test.indexes <- which(folds == i, arr.ind = TRUE)
      
      # Divide the data into training and testing
      test.data <- data[test.indexes, ]
      train.data <- data[-test.indexes, ]
      
      # Now, we fit the model with each kFold
      if (type == "lm") { 
        # Fit the linear model with the training data
        model <- lm(formula, train.data)
        
        # Predict continuous class
        predicted <- data.frame(predict(model, subset(test.data, 
                            select=features), type = "response")) 
        predicted <- predicted[, 1]
        class.name <- colnames(data[class]) 
        real <- test.data[, class.name]
        
        # Calculate MSE
        n.test <- nrow(test.data)
        mean.squared.error <- sum((real - predicted) ^ 2) / n.test
        mse[[length(mse) + 1]] <- mean.squared.error
      } else if (type == "rpart") { 
        # Train the classification tree 
        model <- rpart(formula, train.data) 
        
        # Predict the discrete class and calculate the CCR
        error <- sum(test.data$clase != predict(model, subset(test.data, 
                      select=features), type = "class")) / nrow(test.data)
        no.error <- 1 - error
        ccr[[length(ccr) + 1]] <- no.error
      } else if (type == "neuralnet") { 
        # Training of neural network with backpropagation
        model <- neuralnet(formula, train.data) 
        class.name <- colnames(data[class]) 
        real <- test.data[, class.name]
        test.data <- test.data[ , !colnames(test.data) == class.name]
        
        # Try to predict the values for the test set (with the compute function) 
        predicted <- compute(model, subset(test.data, 
                                            select=features))$net.result 
        
        # Calculate MSE
        n.test <- nrow(test.data)
        mean.squared.error <- sum((real - predicted) ^ 2) / n.test
        mse[[length(mse) + 1]] <- mean.squared.error
      } else if (type == "knn") { 
        class.name <- colnames(data[class]) 
        data.train.labels <- train.data[, class.name]
        train.data <- train.data[ , !colnames(train.data) == class.name]
        real <- test.data$clase
        test.data <- test.data[ , !colnames(test.data) == class.name]
        
        # Training the knn model and calculation of the prediction class 
        prediction <- knn(train = subset(train.data, select=features), 
                          test = subset(test.data, select=features), k= 2, 
                          cl = data.train.labels) 
        
        # Calculate CCR
        error <- sum(real != prediction) / nrow(test.data)
        no.error <- 1 - error
        ccr[[length(ccr) + 1]] <- no.error
      } else {
        stop("You have to choose a training model: lm, neuralnet, knn or rpart")
      }
    }
    # The goal is to maximize the mean of the CCR and the MSE 
    if (type == "rpart" || type == "knn") {
      return(mean(ccr)) 
    } else if (type == "lm" || type == "neuralnet") {
      return(-mean(mse)) 
    }
  }
}