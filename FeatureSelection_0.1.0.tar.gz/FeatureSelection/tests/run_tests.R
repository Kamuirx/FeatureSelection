# Create test suite and invoke all of the tests in the directory 'tests' (file unitTests) 
test.suite <- defineTestSuite("tests", dirs = file.path("tests"), testFileRegexp = 'unitTests.R')

# Run the suite explicitly
test.result <- runTestSuite(test.suite)

# Print out the results in a text format
printTextProtocol(test.result, showDetails = TRUE)