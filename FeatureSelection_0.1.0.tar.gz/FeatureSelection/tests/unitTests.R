# Load test datasets
data1 <- get(load("data/example.RData"))
data2 <- get(load("data/example2.RData"))
data3 <- get(load("data/continuous.RData"))

# Consistency unit tests
testsConsistency <- function() {
  checkEquals(0, binaryConsistency(data1, 'clase', c('x1', 'x2', 'x3')))
  checkEquals(1, binaryConsistency(data2, 'clase', 'x6'))
  checkEquals(1, binaryConsistency(data2, 'clase', c('x5', 'x6')))
  checkEquals(0.5, IEConsistency(data1, 'clase', 'x1'))
  checkEquals(0.6666, IEConsistency(data1, 'clase', c('x1', 'x2')), 
              tolerance = 1e-3)
  checkEquals(1, IEConsistency(data2, 'clase', c('x1', 'x2', 'x3', 'x4', 'x5', 
                                                 'x6')))
  checkEquals(0.8666, IEPConsistency(data1, 'clase', c('x1', 'x2', 'x3')), 
              tolerance = 1e-4)
  checkEquals(0.7333, IEPConsistency(data1, 'clase', c('x1', 'x3')), 
              tolerance = 1e-4)
  checkEquals(1, IEPConsistency(data2, 'clase', 'x6'))
  checkEquals(0.5, roughsetConsistency(data1, 'clase', c('x1', 'x2', 'x3')))
  checkEquals(0, roughsetConsistency(data2, 'clase', 'x3'))
  checkEquals(1, roughsetConsistency(data2, 'clase', c('x1', 'x2', 'x3', 'x4', 
                                                       'x5', 'x6')))
}

# Entropy based unit tests
testsEntropy <- function() {
  checkEquals(0, mutualInformation(data2, 'clase', 'x1'))
  checkEquals(0.4591, mutualInformation(data2, 'clase', 'x2'), tolerance = 1e-3)
  checkEquals(0.4591, mutualInformation(data1, 'clase', c('x1', 'x2')), 
              tolerance = 1e-3)
  checkEquals(1, mutualInformation(data1, 'clase', c('x2', 'x3')))
  checkEquals(0, gainRatio(data1, 'clase', 'x1'))
  checkEquals(0.5, gainRatio(data1, 'clase', 'x2'))
  checkEquals(0.5, gainRatio(data2, 'clase', c('x1', 'x2')))
  checkEquals(0.6853, gainRatio(data1, 'clase', c('x1', 'x2', 'x3')), 
              tolerance = 1e-3)
  checkEquals(0, symmetricalUncertain(data1, 'clase', 'x1'))
  checkEquals(0.4398, symmetricalUncertain(data1, 'clase', 'x3'), 
              tolerance = 1e-3)
  checkEquals(0.7216, symmetricalUncertain(data2, 'clase', c('x1', 'x2', 'x3', 
                                         'x4', 'x5', 'x6')), tolerance = 1e-3)
  checkEquals(1, symmetricalUncertain(data2, 'clase', 'x6'))
}

# Gini index unit tests
testsGini <- function() {
  checkEquals(0.3888, giniIndex(data1, 'clase', 'x1'), tolerance = 1e-3)
  checkEquals(0.5833, giniIndex(data1, 'clase', 'x2'), tolerance = 1e-4)
  checkEquals(0.5555, giniIndex(data1, 'clase', 'x3'), tolerance = 1e-3)
  checkEquals(0.7777, giniIndex(data2, 'clase', c('x2', 'x3')), tolerance=1e-3)
  checkEquals(0.5555, giniIndex(data2, 'clase', c('x1', 'x3')), tolerance=1e-3)
  checkEquals(1, giniIndex(data2, 'clase', c('x1', 'x3', 'x5', 'x6')))
}

# Chi squared unit tests
testsChiSquared <- function() {
  checkEquals(0, chiSquared(data1, 'clase', 'x1'))
  checkEquals(3, chiSquared(data2, 'clase', 'x2'))
  checkEquals(1.3333, chiSquared(data2, 'clase', 'x5'), tolerance = 1e-4)
  checkEquals(12, chiSquared(data2, 'clase', 'x6'))
  checkEquals(c(0, 3, 3.3333, 1.3333, 1.3333, 12), chiSquared(data2, 'clase', 
                    c('x1', 'x2', 'x3', 'x4', 'x5', 'x6')), tolerance = 1e-5)
  checkEquals(c(0, 0.7071, 0.7453, 0.4714, 0.4714, 1), cramer(data2, 'clase', 
                    c('x1', 'x2', 'x3', 'x4', 'x5', 'x6')), tolerance = 1e-4)
  checkEquals(0, cramer(data1, 'clase', 'x1'))
  checkEquals(0.7071, cramer(data1, 'clase', 'x2'), tolerance = 1e-5)
  checkEquals(0.7453, cramer(data1, 'clase', 'x3'), tolerance = 1e-4)
  checkEquals(c(0, 0.7071, 0.7453), cramer(data1, 'clase', c('x1', 'x2', 'x3')), 
              tolerance = 1e-4)
}

# Determination coefficient unit tests
testsDetermination <- function() {
  checkEquals(0.1002, determinationCoefficient(data3, 'clase', 'x1'), 
              tolerance = 1e-3)
  checkEquals(0.0032, determinationCoefficient(data3, 'clase', 'x6'), 
              tolerance = 1e-2)
  checkEquals(0.1541, determinationCoefficient(data3, 'clase', c('x3', 'x5')), 
              tolerance = 1e-3)
  checkEquals(0.1112, determinationCoefficient(data3, 'clase', c('x2', 'x1')), 
              tolerance = 1e-3)
  checkEquals(0.5568, determinationCoefficient(data3, 'clase', c('x1', 'x2', 
                           'x3', 'x4', 'x5', 'x6', 'x7')), tolerance = 1e-4)
}

# Breadth first search unit tests
testsExhaustiveSearch <- function() {
  checkEquals('x6', breadthFirstSearch(data2, 'clase', cramer))
  checkEquals('x6', breadthFirstSearch(data2, 'clase', IEConsistency))
  checkEquals(c('x2', 'x3'), breadthFirstSearch(data1, 'clase', roughsetConsistency))
  checkEquals('x3', breadthFirstSearch(data1, 'clase', chiSquared))
  checkEquals(c('x2', 'x3'), breadthFirstSearch(data1, 'clase', giniIndex))
  checkEquals(c('x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7'), 
              breadthFirstSearch(data3, 'clase', determinationCoefficient))
}

# Cut off unit tests
testsIndividual <- function() {
  checkEquals('x3', selectKBest(data1, 'clase', IEPConsistency, 1))
  checkEquals('x2', selectKBest(data1, 'clase', giniIndex, 1))
  checkEquals(c('x6', 'x2', 'x3', 'x4'), selectKBest(data2, 'clase', giniIndex, 4))
  checkEquals(c('x3', 'x1', 'x2'), 
              selectKBest(data3, 'clase', determinationCoefficient, 3))
  checkEquals('x6', selectPercentile(data2, 'clase', giniIndex, 20))
  checkEquals(c('x6', 'x2'), selectPercentile(data2, 'clase', giniIndex, 30))
  checkEquals(c('x6', 'x2', 'x3'), selectPercentile(data2, 'clase', giniIndex, 50))
  checkEquals(c('x1', 'x2', 'x4', 'x5', 'x3', 'x6'),
              selectThreshold(data2, 'clase', IEPConsistency, 0.1))
  checkEquals(c('x2', 'x4', 'x5', 'x3', 'x6'), 
              selectThreshold(data2, 'clase', IEPConsistency, 0.6))
  checkEquals('x6', selectThreshold(data2, 'clase', IEPConsistency, 0.9))
  checkEquals('x3', selectThresholdRange(data1, 'clase', IEPConsistency, 0.9))
  checkEquals(c('x3', 'x6'), selectThresholdRange(data2, 'clase', IEPConsistency, 0.6))
  checkEquals(c('x6', 'x3', 'x2', 'x4', 'x5', 'x1'), 
              selectDifference(data2, 'clase', symmetricalUncertain, 0.6))
  checkEquals(c('x6', 'x3', 'x2', 'x4', 'x5'), 
              selectDifference(data2, 'clase', cramer, 0.3))
  checkEquals(c('x3', 'x2'), selectDifference(data1, 'clase', cramer, 0.2))
  checkEquals(c('x3', 'x2'), selectSlope(data1, 'clase', cramer, 0.2))
  checkEquals('x3', selectSlope(data1, 'clase', cramer, 0.1))
}

# Sequential search unit tests
testsSequential <- function() {
  checkEquals(c('x2', 'x3'), sfs(data1, 'clase', IEConsistency))
  checkEquals('x6', sfs(data2, 'clase', symmetricalUncertain))
  checkEquals(c('x3', 'x1', 'x5', 'x6', 'x4', 'x2', 'x7'), 
              sfs(data3, 'clase', determinationCoefficient))
  checkEquals(c('x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7'), 
              sbs(data3, 'clase', determinationCoefficient))
  checkEquals('x6', sbs(data2, 'clase', IEPConsistency))
  checkEquals(c('x2', 'x3'), sffs(data1, 'clase', roughsetConsistency))
  checkEquals('x6', sffs(data2, 'clase', gainRatio))
  checkEquals('x6', sfbs(data2, 'clase', binaryConsistency))
  checkEquals(c('x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7'), 
              sfbs(data3, 'clase', determinationCoefficient))
}